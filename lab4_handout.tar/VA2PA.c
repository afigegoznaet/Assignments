#include <stdio.h>
#include <stdlib.h>
#include "VA2PA.h" 




main(int argc, char ** argv) {
  char input_line[64];
  if (argc != 2) {
    printf("Usage: %s <prefix name>\n",argv[0]);
    exit(2);
  }

  initialize_pagetable(argv[1],VPN,PPN);


  do  {
     int virtual; 
     printf("Enter a virtual address or -1 to exit:  ");
     fgets(input_line,64,stdin);
     virtual = atoi(input_line);
     if (virtual == -1) break;

  } while (1);
}




