
#define OFFSET 11
#define VPN 9
#define PPN 13

// initialize function must be called at the start of the program.
//    parameters: string to initialize random number generator
//                number of bits in VPN
//                number of bits in PPN
int initialize_pagetable(char *, int, int);

// returns the physical address (PPN) for the given virtual page (VPN)
// or -1 if the page is not in memory  
int lookup_pagetable(int);

// dump the contents of the page table.  Useful for debugging
int print_pagetable();


